import React from 'react'
import './DescriptionBox.css'

const DescriptionBox = () => {
  return (
    <div className='descriptionbox'>
        <div className="descriptionbox-navigator">
            <div className="descriptionbox-nav-box">Description</div>
            <div className="descriptionbox-nav-box fade">Reviews (122)</div>
        </div>
        <div className="descriptionbox-description">
            <p>Welcome to SHOPPER, your one-stop online destination for all your shopping needs!
            We bring you a diverse range of high-quality products at unbeatable prices, from the
            latest fashion trends and cutting-edge electronics to home essentials and unique gifts.
            Our extensive catalog features top brands and trusted suppliers, ensuring every item meets
            our rigorous quality standards. Enjoy competitive pricing, special deals, and discounts, 
            all while shopping securely with advanced encryption technology protecting your personal and 
            payment information. With fast shipping and a dedicated customer support team ready to assist,
            we prioritize your satisfaction. Plus, our hassle-free return policy ensures stress-free shopping.
            Discover why SHOPPER is the preferred choice for shoppers worldwide—happy shopping!</p>
            
            <p>Ecommrece website typically display product or services along with detailed description, images,
            prices and any avaiable variations(color,size).Each product usually has it's own dedicated page with
            relevant information</p>
        </div>
    </div>
  )
}

export default DescriptionBox