import React from 'react'
import { useContext } from 'react'
import { ShopContext } from '../Context/ShopContext'
import { useParams } from 'react-router-dom'
import Breadcum from '../Components/Breadcrums/Breadcum'
import DisplayProducts from '../Components/DisplayProducts/DisplayProducts'
import DescriptionBox from '../Components/DescriptionBox/DescriptionBox'
import Relatedproducts from '../Components/Relatedproducts/Relatedproducts'

const Product = () => {
  const {all_products} = useContext(ShopContext)
  const {productId} = useParams()
  const product = all_products.find((e)=>e.id===Number(productId))
  return (
    <div>
      <Breadcum product={product}/>
      <DisplayProducts product={product}/>
      <DescriptionBox />
      <Relatedproducts />
    </div>
  )
}

export default Product